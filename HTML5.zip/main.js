function setTime() {
   // body...
   const date=new Date();
   let h = date.getHours();
   let m=date.getMinutes();
   let s= date.getSeconds();
   document.getElementById("right").innerHTML=h+":"+m+":"+s;
   setTimeout(setTime,1000);
}

      